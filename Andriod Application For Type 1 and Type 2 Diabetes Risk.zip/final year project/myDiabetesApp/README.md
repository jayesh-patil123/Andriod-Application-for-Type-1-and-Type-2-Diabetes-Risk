# myDiabetesApp
An Android mobile app, that helps users to manage and monitor their diabetes
